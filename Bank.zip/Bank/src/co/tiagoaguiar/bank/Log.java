    package co.tiagoaguiar.bank;

    public class Log {
        public void out(String message) {
            System.out.println("LOG: " + message);
        }
    }
